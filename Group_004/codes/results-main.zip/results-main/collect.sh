# extract_first_line() {
#     local file="$1"
#     local pattern="^s td [0-9]+ [0-9]+ [0-9]+"
#     local first_line=$(grep -m 1 "$pattern" "$file")
#     echo "$first_line"
# }

# extract_first_line() {
#     local file="$1"
#     local pattern="^s td [0-9]+ [0-9]+ [0-9]+"
#     local first_line=$(grep -m 1 "$pattern" "$file")
#     echo "$first_line"
# }

# extract_first_line() {
#     local file="$1"
#     awk '/^s td [0-9]+ [0-9]+ [0-9]+/{print; exit}' "$file"
    
# }

extract_second_number() {
    local file="$1"
    local line=$(awk '/^s td [0-9]+ [0-9]+ [0-9]+/{print; exit}' "$file")
    local second_number=$(echo "$line" | awk '{print $4}')
    echo "$second_number"
}

root=$1

for file in $(ls $root); do
    second_number=$(extract_second_number "$root/$file")
    echo "$file $second_number"

done


# file="./exact-unzipped/ex001.td"
# first_line=$(extract_second_number "$file")

# echo "The second number: $first_line"