root=$1
unzippedPath=$2

extract_extension() {
    local filename="$1"
    local extension="${filename##*.}"
    echo "$extension"
}

extract_xz_file() {
    local xz_file="$1"
    local output_directory="$2"
    unxz "$xz_file" -c > "$output_directory/$(basename "$xz_file" .xz)"
}

# Example usage
# filename="example.txt"
# extension=$(extract_extension "$filename")
for file in $(ls $root); do
    # echo $file
    extension=$(extract_extension "$file")
    if [ $extension = "xz" ]; then
        echo $file
        # unzip $root/$file -d $unzippedPath
        extract_xz_file "$root/$file" "$unzippedPath"
    fi

done