import matplotlib.pyplot as plt

def plot_bar_from_file(filename):
    # Lists to store 'a' and 'b' values
    a_values = []
    b_values = []

    # Read the file
    with open(filename, 'r') as file:
        # Iterate over each line
        for line in file:
            # Split the line into 'a' and 'b' values
            a, b = map(float, line.strip().split())
            a_values.append(a)
            b_values.append(b)
    
    # Calculate b/a values
    ratio_values = [b - a for a, b in zip(a_values, b_values)]

    # Plotting
    plt.bar(range(len(ratio_values)), ratio_values)
    plt.xlabel('Index')
    plt.ylabel('b / a')
    plt.title('b / a Values')
    plt.ylim(0, max(ratio_values) + .2)  # Set y-axis limits
    plt.show()

# Example usage
filename = 'results.txt'  # Replace 'data.txt' with your file name
plot_bar_from_file(filename)
