filename1 = "exact_solutions.txt"
filename2 = "exact_heuristic.txt"

with open(filename1) as f1:
    with open(filename2) as f2:
        for line1, line2 in zip(f1, f2):
            print(line1.strip().split(" ")[1], line2.strip().split(" ")[1])